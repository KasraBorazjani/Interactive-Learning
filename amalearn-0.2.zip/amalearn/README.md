# AMALearn

For installation, run: 
`pip install -e .`