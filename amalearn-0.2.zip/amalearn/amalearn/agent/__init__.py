from amalearn.agent.agent_base import AgentBase
from amalearn.agent.random_bandit_agent import RandomBanditAgent
from amalearn.agent.social_agent import SocialAgent