from amalearn.reward.reward_base import RewardBase
from amalearn.reward.gaussian_reward import GaussianReward