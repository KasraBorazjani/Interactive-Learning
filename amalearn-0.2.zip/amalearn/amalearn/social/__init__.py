from amalearn.social.message import Message
from amalearn.social.observable import Observable